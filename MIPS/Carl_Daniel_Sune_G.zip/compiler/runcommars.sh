camlrunm BIN/Paladim DATA/$1.pal; SRC/mars.sh DATA/$1.asm
